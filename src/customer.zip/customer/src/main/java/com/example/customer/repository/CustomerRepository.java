package com.example.customer.repository;

import com.example.customer.domain.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Repository
@Transactional //??
public interface CustomerRepository extends JpaRepository<Customer, Integer> {

    Optional<Customer> findById(int id);

    @Cacheable("CustomerCache") //??
    @Query("SELECT b from Customer b where b.userName = :userName")
        // ??b
    Customer findByUserName(@Param("userName") String userName);

    @Query(nativeQuery = true, value = "{CALL findAll()}")
    List<Customer> getCustomers();

    @Query(nativeQuery = true, value = "{CALL findByName(:name)}")
    List<Customer> getCustomerBy(String name);

}
