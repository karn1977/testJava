package com.example.customer.model;

import com.example.customer.domain.Customer;

import java.util.List;

public class CustomerResponse {

    private List<Customer> customers;

    private String userDetail;

    public List<Customer> getCustomers() {
        return customers;
    }

    public void setCustomers(List<Customer> customers) {
        this.customers = customers;
    }
}
