package com.example.customer.controller;


import com.example.customer.domain.Customer;
import com.example.customer.repository.SqlRepository;
import com.example.customer.service.CustomerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CustomerController {

    Logger logger = LoggerFactory.getLogger(CustomerController.class);

    @Autowired
    private CustomerService customerService;

    @Autowired
    private SqlRepository sqlRepo;

//    @GetMapping("/customers")
//    public CustomerResponse getCustomerService(){
//        CustomerResponse response = new CustomerResponse();
//        response.setCustomers(customerService.getAllCustomers());
//        return response;
//    }

//    @GetMapping("/customers")
//    public List<Customer> findAll(){
//        return sqlRepo.getAllCustomerInfo();
//    }

//    @GetMapping("/customers")
//    public List<Customer> findAll(){
//        return customerService.getCustomers();
//    }

    @GetMapping("/customers")
    public List<Customer> getCustomerByName(@RequestParam String name){
        return customerService.getByCustomer(name);
    }

    @GetMapping("/customer/findByName/{name}")
    public List<Customer> findByName(@PathVariable String name){
        return sqlRepo.getCustomerInfoByName(name);
    }

//    @GetMapping("/customer/{userName}")
//    public Customer getCustomerByUsername(@PathVariable String userName){
//        return customerService.findByUserName(userName);
//    }

    @GetMapping("/customers/{id}")
    public Customer getCustomer(@PathVariable int id){
        return customerService.getCustomerById(id);
    }

    @PostMapping ("/customer")
    public void saveCustomer(@RequestBody Customer customer){
        customerService.addCustomer(customer);
    }

    @PutMapping ("/customer/{id}")
    public void updateCustomer(@PathVariable int id, @RequestBody Customer customer){
        customerService.updateCustomer(id, customer);
    }

    @DeleteMapping ("/customers/{id}")
    public void deleteCustomer(@PathVariable int id){
        customerService.deleteCustomerById(id);
    }
}
