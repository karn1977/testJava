package com.example.customer.domain;

import io.netty.util.internal.SuppressJava6Requirement;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;

import javax.persistence.*;
import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table
//@NamedStoredProcedureQueries({@NamedStoredProcedureQuery(name = "findAll", procedureName = "findAll"),
//        @NamedStoredProcedureQuery(name = "findByName", procedureName = "FindByName", parameters =
//                {@StoredProcedureParameter(mode = ParameterMode.IN, name = "cName", type = String.class)})})

public class Customer {

    @Id
    private int id;
    @NotBlank(message = "Name must be in Character")
    private String name;

    @Email(message = "Must have valid email")
//    @Pattern(regexp = "\\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}\\b")
//    @Pattern(regexp = "^(.+)@(.+)$")
    private String email;
    private String userName;
//    @Transient
//    private String userDetail;

    public Customer(int id, String name, String email, String userName) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.userName = userName;
    }

    public Customer() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
