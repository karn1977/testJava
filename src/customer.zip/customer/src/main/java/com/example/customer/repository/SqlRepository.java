package com.example.customer.repository;

import com.example.customer.domain.Customer;
import com.example.customer.domain.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.StoredProcedureQuery;
import java.util.List;

@Repository
public class SqlRepository {

    @Autowired
    private EntityManager em;

    @SuppressWarnings("unchecked")
    public void twoTable(){
        StoredProcedureQuery storedProcedureQuery = em.createStoredProcedureQuery("twotablejoin", Customer.class);
        List<Customer> customer = storedProcedureQuery.getResultList();
        storedProcedureQuery = em.createStoredProcedureQuery("twotablejoin", Product.class);
        List<Product> product=null;
        while (storedProcedureQuery.hasMoreResults()){
            product = storedProcedureQuery.getResultList();
        }
        System.out.println(product);
    }

    @SuppressWarnings("unchecked")
    public List<Customer> getAllCustomerInfo(){
        return em.createNamedStoredProcedureQuery("findAll").getResultList();
    }


    @SuppressWarnings("unchecked")
    public List<Customer> getCustomerInfoByName(String input){
        return em.createNamedStoredProcedureQuery("findByName").setParameter("cName", input).getResultList();
    }
}
